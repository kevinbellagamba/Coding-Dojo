from courses_app.models import Course
from django.shortcuts import render, redirect
from django.contrib import messages

# Create your views here.
from django.shortcuts import render, redirect
def courses(request):     
    context = {
        'courses' : Course.objects.all(),
    }
    return render(request, "index.html", context)

def addCourse(request):
    if request.method == "POST":
        errors = Course.objects.validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request,value)
            return redirect('/courses')
        else:
            Course.objects.create(
            name=request.POST['name'], 
            description=request.POST['description'], 
            )
            messages.success(request, "Course Added")
            return redirect("/courses")

def deleteCourse(request, course_id):
    context = {
        'course' : Course.objects.get(id=course_id)
    }
    return render(request, 'deleteCourse.html', context)

def removeCourse(request, course_id):
    delete = Course.objects.get(id=course_id)
    delete.delete()
    return redirect('/courses')