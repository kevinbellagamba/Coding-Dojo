from django.urls import path, include
from . import views

urlpatterns = [
    path('courses', views.courses),
    path('courses/create', views.addCourse),
    path('courses/delete/<int:course_id>', views.deleteCourse),
    path('courses/remove/<int:course_id>', views.removeCourse),
]