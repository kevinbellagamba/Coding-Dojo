from books_authors_app.models import Book, Author
from django.shortcuts import render

# Create your views here.

from django.shortcuts import render, HttpResponse, redirect
def index(request):
    return render(request, "index.html")