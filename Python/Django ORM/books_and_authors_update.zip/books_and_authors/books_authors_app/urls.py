from django.urls import path     
from . import views

urlpatterns = [
    path('', views.index),
    path('book', views.index),
    path('addBook', views.addBook),
    path('book/<int:book_id>', views.viewBook),
    path('book/<int:book_id>/updateAuthors', views.updateAuthors),
    path('authors', views.authors),
    path('addAuthor', views.addAuthor),
    path('author/<int:authors_id>', views.viewAuthor),
    path('author/<int:authors_id>/updateBooks', views.updateBooks),
]