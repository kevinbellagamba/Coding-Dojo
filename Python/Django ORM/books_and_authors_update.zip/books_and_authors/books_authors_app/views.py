from books_authors_app.models import Book, Author
from django.shortcuts import render

# Create your views here.

from django.shortcuts import render, HttpResponse, redirect
def index(request):     
    context = {
    'books' : Book.objects.all(),
    'authors' : Author.objects.all(),
    }
    return render(request, "index.html", context)

def addBook(request):
    Book.objects.create(
    title=request.POST['title'], 
    description=request.POST['description'], 
    )
    return redirect("/")

def viewBook(request, book_id):
    context = {
        "book" : Book.objects.get(id=book_id),   
        "authors" : Author.objects.exclude(books__id=book_id)
    }
    return render(request, 'books.html', context)

def updateAuthors(request, book_id):
    addAuthor = Author.objects.get(id = request.POST['select_author'])
    Book.objects.get(id = book_id).authors.add(addAuthor)
    return redirect(f"/book/{book_id}")

def authors(request):     
    context = {
    'books' : Book.objects.all(),
    'authors' : Author.objects.all(),
    }
    return render(request, "indexauthors.html", context)

def addAuthor(request):
    Author.objects.create(
    first_name=request.POST['first_name'], 
    last_name=request.POST['last_name'], 
    )
    return redirect("/authors")

def viewAuthor(request, authors_id):
    context = {
        "author" : Author.objects.get(id=authors_id),   
        "books" : Book.objects.exclude(authors__id=authors_id)
    }
    return render(request, 'authors.html', context) 

def updateBooks(request, authors_id):
    addBook = Book.objects.get(id = request.POST['select_book'])
    Author.objects.get(id = authors_id).books.add(addBook)
    return redirect(f"/author/{authors_id}")