from django.apps import AppConfig


class FootballAppConfig(AppConfig):
    name = 'football_app'
