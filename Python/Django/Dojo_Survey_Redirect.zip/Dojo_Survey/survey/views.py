from django.shortcuts import redirect, render

# Create your views here.
from django.shortcuts import render, HttpResponse
def index(request):
    return render(request, "index.html")

def result(request):
    if request.method == "POST":
        context = {
            'name': request.POST['name'],
            'language': request.POST['language'],
            'location': request.POST['location'],
            'comment': request.POST['comment']
        }
        request.session['forminfo'] = request.POST

        return redirect("/success")
    

def showResults(request):
    print('', request.POST)
    return render(request, "result.html")