from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, HttpResponse
def index(request):
    return render(request, "index.html")

def result(request):
    if request.method == "POST":
        context = {
            'name': request.POST['name'],
            'language': request.POST['language'],
            'location': request.POST['location'],
            'comment': request.POST['comment']
        }
        return render(request, "result.html", context)
    return render(request, "result.html")